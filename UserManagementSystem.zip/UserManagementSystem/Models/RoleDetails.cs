﻿namespace UserManagementSystem.Models
{
    public class RoleDetails
    {
        public int RoleId { get; set; }
        public string? RoleName { get; set; }
        public string? Location { get; set; }

    }
}
