﻿namespace UserManagementSystem.Models
{
    public class ApiResponse
    {

        public string? Status { get; set; }
        public int StatusCode { get; set; }
    }
}
