﻿using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using UserManagementSystem.CoreLayer.Command.DeactivateUser;
using UserManagementSystem.CoreLayer.Command.InsertUser;
using UserManagementSystem.CoreLayer.Command.UpdateUser;
using UserManagementSystem.CoreLayer.Query.GetAllRoles;
using UserManagementSystem.CoreLayer.Query.GetAllUsers;
using UserManagementSystem.CoreLayer.Query.GetUserById;
using UserManagementSystem.DbLayer.Interface;
using UserManagementSystem.Models;

namespace UserManagementSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IMediator _mediator;

        public UserController(IMediator mediator)
        {
            this._mediator = mediator;
        }


        [HttpPost("Insertusers")]
        public async Task<IActionResult> Insertusers(UserDetails reuquest)
        {

            var response = await _mediator.Send(new InsertUserCommand(reuquest));
            return Ok(response);

        }

        [HttpPut("Updateusers")]
        public async Task<IActionResult> Updateusers(UserDetails reuquest)
        {

            var response = await _mediator.Send(new UpdateUserCommand(reuquest));
            return Ok(response);

        }

        [HttpDelete("Deactivateusers/{UserId}")]
        public async Task<IActionResult> Deactivateusers(int UserId)
        {
            var response = await _mediator.Send(new DeactivateUserCommand(UserId));
            return Ok(response);
        }

        [HttpGet("GetAllusers")]
        public async Task<IActionResult> GetAllusers()
        {
            var response = await _mediator.Send(new GetAllUsersQuery());
            return Ok(response);

        }

        [HttpGet("GetAllRoles")]
        public async Task<IActionResult> GetAllRoles()
        {
            var response = await _mediator.Send(new GetAllRolesQuery());
            return Ok(response);

        }


        [HttpGet("GetusersById/{UserId}")]
        public async Task<IActionResult> GetusersById(int UserId)
        {
            var response = await _mediator.Send(new GetUserByIdQuery(UserId));
            return Ok(response);

        }

    }

}