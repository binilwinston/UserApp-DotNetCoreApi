﻿using MediatR;
using UserManagementSystem.CoreLayer.Command.InsertUser;
using UserManagementSystem.DbLayer.Interface;
using UserManagementSystem.Models;

namespace UserManagementSystem.CoreLayer.Command.UpdateUser
{
    public class UpdateUserCommandHandler : IRequestHandler<UpdateUserCommand, ApiResponse>
    {
        private IUserRepository repos { get; set; }
        public UpdateUserCommandHandler(IUserRepository repos)
        {
            this.repos = repos;
        }

        public async Task<ApiResponse> Handle(UpdateUserCommand request, CancellationToken cancellationToken)
        {
            var response = await repos.UpdateUsers(request.userdata);

            return response;


        }

    }
}
