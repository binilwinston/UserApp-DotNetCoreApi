﻿using MediatR;
using UserManagementSystem.Models;

namespace UserManagementSystem.CoreLayer.Command.UpdateUser
{
    public class UpdateUserCommand : IRequest<ApiResponse>
    {
        public UserDetails userdata { get; set; }
        public UpdateUserCommand(UserDetails userdata)
        {
            this.userdata = userdata;
        }
    }
}
