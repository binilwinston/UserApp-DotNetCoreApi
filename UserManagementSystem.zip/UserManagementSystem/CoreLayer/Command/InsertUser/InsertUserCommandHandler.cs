﻿using MediatR;
using UserManagementSystem.DbLayer.Interface;
using UserManagementSystem.Models;

namespace UserManagementSystem.CoreLayer.Command.InsertUser
{
    public class InsertUserCommandHandler : IRequestHandler<InsertUserCommand, ApiResponse>
    {
        private IUserRepository repos { get; set; }
        public InsertUserCommandHandler(IUserRepository repos)
        {
            this.repos = repos;
        }

        public async Task<ApiResponse> Handle(InsertUserCommand request, CancellationToken cancellationToken)
        {
            var response = await repos.InsertUsers(request.userdata);

            return response;


        }

    }
}
