﻿using MediatR;
using UserManagementSystem.Models;

namespace UserManagementSystem.CoreLayer.Command.InsertUser
{
    public class InsertUserCommand : IRequest<ApiResponse>
    {

        public UserDetails userdata { get; set; }
        public InsertUserCommand(UserDetails userdata)
        {
            this.userdata = userdata;
        }


    }
}
