﻿using MediatR;
using UserManagementSystem.Models;

namespace UserManagementSystem.CoreLayer.Command.DeactivateUser
{
    public class DeactivateUserCommand : IRequest<int>
    {
        public int UserId { get; set; }
        public DeactivateUserCommand(int UserId)
        {
            this.UserId = UserId;
        }

    }
}
