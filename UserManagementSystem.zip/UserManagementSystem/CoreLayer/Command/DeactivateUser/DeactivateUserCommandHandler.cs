﻿using MediatR;
using UserManagementSystem.DbLayer.Interface;
using UserManagementSystem.Models;

namespace UserManagementSystem.CoreLayer.Command.DeactivateUser
{
    public class DeactivateUserCommandHandler : IRequestHandler<DeactivateUserCommand, int>
    {
        private IUserRepository repos { get; set; }
        public DeactivateUserCommandHandler(IUserRepository repos)
        {
            this.repos = repos;
        }
        public async Task<int> Handle(DeactivateUserCommand request, CancellationToken cancellationToken)
        {
            var response = await repos.DeactivateUsers(request.UserId);

            return response;


        }

    }
}
