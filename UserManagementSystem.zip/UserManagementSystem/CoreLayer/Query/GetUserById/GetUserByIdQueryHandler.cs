﻿using MediatR;
using UserManagementSystem.DbLayer.Interface;
using UserManagementSystem.Models;

namespace UserManagementSystem.CoreLayer.Query.GetUserById
{
    public class GetUserByIdQueryHandler : IRequestHandler<GetUserByIdQuery, UserDetails>
    {

        private IUserRepository repos { get; set; }
        public GetUserByIdQueryHandler(IUserRepository repos)
        {
            this.repos = repos;
        }
        public async Task<UserDetails> Handle(GetUserByIdQuery request, CancellationToken cancellationToken)
        {
            var response = await repos.SelectUserById(request.UserId);
            return response;

        }

    }
}
