﻿using MediatR;
using UserManagementSystem.Models;

namespace UserManagementSystem.CoreLayer.Query.GetUserById
{
    public class GetUserByIdQuery : IRequest<UserDetails>
    {
        public int UserId { get; set; }
        public GetUserByIdQuery(int UserId)
        {
            this.UserId = UserId;
        }

    }
}
