﻿using MediatR;
using UserManagementSystem.Models;

namespace UserManagementSystem.CoreLayer.Query.GetAllUsers
{
    public class GetAllUsersQuery : IRequest<List<UserDetails>>
    {


    }
}
