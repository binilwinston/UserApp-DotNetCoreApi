﻿using MediatR;
using UserManagementSystem.DbLayer.Interface;
using UserManagementSystem.Models;

namespace UserManagementSystem.CoreLayer.Query.GetAllUsers
{
    public class GetAllUsersQueryHandler : IRequestHandler<GetAllUsersQuery, List<UserDetails>>
    {

        private IUserRepository repos { get; set; }
        public GetAllUsersQueryHandler(IUserRepository repos)
        {
            this.repos = repos;
        }
        public async Task<List<UserDetails>> Handle(GetAllUsersQuery request, CancellationToken cancellationToken)
        {
            var response = await repos.SelectAllUsers();

            return response;


        }

    }
}
