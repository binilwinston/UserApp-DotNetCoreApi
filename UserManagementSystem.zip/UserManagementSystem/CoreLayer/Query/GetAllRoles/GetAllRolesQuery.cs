﻿using MediatR;
using UserManagementSystem.Models;

namespace UserManagementSystem.CoreLayer.Query.GetAllRoles
{
    public class GetAllRolesQuery : IRequest<List<RoleDetails>>
    {

    }
}
