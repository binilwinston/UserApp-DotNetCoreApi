﻿using MediatR;
using UserManagementSystem.CoreLayer.Query.GetAllUsers;
using UserManagementSystem.DbLayer.Interface;
using UserManagementSystem.Models;

namespace UserManagementSystem.CoreLayer.Query.GetAllRoles
{
    public class GetAllRolesQueryHandler : IRequestHandler<GetAllRolesQuery, List<RoleDetails>>
    {
        private IUserRepository repos { get; set; }
        public GetAllRolesQueryHandler(IUserRepository repos)
        {
            this.repos = repos;
        }
        public async Task<List<RoleDetails>> Handle(GetAllRolesQuery request, CancellationToken cancellationToken)
        {
            var response = await repos.SelectAllRoles();
            return response;


        }


    }
}
