﻿using UserManagementSystem.Models;

namespace UserManagementSystem.DbLayer.Interface
{
    public interface IUserRepository
    {
        Task<List<UserDetails>> SelectAllUsers();
        Task<List<RoleDetails>> SelectAllRoles();
        Task<ApiResponse> InsertUsers(UserDetails request);
        Task<UserDetails> SelectUserById(int UserId);
        Task<ApiResponse> UpdateUsers(UserDetails request);
        Task<int> DeactivateUsers(int UserId);


    }
}
