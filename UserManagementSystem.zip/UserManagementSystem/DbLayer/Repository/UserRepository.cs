﻿using Dapper;
using System.Data;
using System.Net.Mail;
using System.Text.RegularExpressions;
using UserManagementSystem.DbLayer.Interface;
using UserManagementSystem.Models;

namespace UserManagementSystem.DbLayer.Repository
{
    public class UserRepository : IUserRepository
    {
        private readonly DapperContext _context;
        public UserRepository(DapperContext context)
        {
            _context = context;
        }

        public async Task<List<UserDetails>> SelectAllUsers()
        {
            var query = "SELECT_ALL_USERS";

            using (var connection = _context.CreateConnection())
            {
                var companies = await connection.QueryAsync<UserDetails>(query);
                return companies.ToList();
            }
        }

        public async Task<List<RoleDetails>> SelectAllRoles()
        {
            var query = "SELECT_ALL_ROLES";

            using (var connection = _context.CreateConnection())
            {
                var companies = await connection.QueryAsync<RoleDetails>(query);
                return companies.ToList();
            }
        }

        public async Task<ApiResponse> InsertUsers(UserDetails request)
        {
            ApiResponse response = new ApiResponse();

            if (string.IsNullOrWhiteSpace(request.Name) || string.IsNullOrWhiteSpace(request.Email) || string.IsNullOrWhiteSpace(request.Role))
            {
                response.StatusCode = 600;
                response.Status = "BAD_REQUEST";
                return response;
            }

            bool IsValid = IsValidEmail(request.Email);
            if(! IsValid)
            {
                response.StatusCode = 601;
                response.Status = "INVALID EMAIL";
                return response;
            }
            try
            {
                var query = "INSERT_NEW_USER";
                var parameters = new DynamicParameters();
                parameters.Add("@Name", request.Name, DbType.String, ParameterDirection.Input);
                parameters.Add("@Email", request.Email, DbType.String, ParameterDirection.Input);
                parameters.Add("@Role", request.Role, DbType.String, ParameterDirection.Input);
                parameters.Add("@Status", request.Status, DbType.String, ParameterDirection.Input);

                using (var connection = _context.CreateConnection())
                {
                    var customerresponse = await connection.ExecuteAsync(query, parameters, commandType: CommandType.StoredProcedure);

                    response.StatusCode = 200;
                    response.Status = "Saved Successfully";
                    return response;
                }
            }
            catch
            {
                response.StatusCode = 500;
                response.Status = "Internal Server Error";
                return response;
            }


        }

        public async Task<UserDetails> SelectUserById(int UserId)
        {
            var query = "SELECT_USERDETAILS_BY_ID";
            var parameters = new DynamicParameters();
            parameters.Add("@UserId", UserId, DbType.Int16, ParameterDirection.Input);
            using (var connection = _context.CreateConnection())
            {
                var userresponse = await connection.QuerySingleOrDefaultAsync<UserDetails>(query, parameters, commandType: CommandType.StoredProcedure);
                return userresponse;
            }
        }

        public async Task<ApiResponse> UpdateUsers(UserDetails request)
        {
            ApiResponse response = new ApiResponse();

            if (string.IsNullOrWhiteSpace(request.Name) || string.IsNullOrWhiteSpace(request.Email) || string.IsNullOrWhiteSpace(request.Role))
            {
                response.StatusCode = 600;
                response.Status = "BAD_REQUEST";
                return response;

            }
            bool IsValid = IsValidEmail(request.Email);
            if (!IsValid)
            {
                response.StatusCode = 601;
                response.Status = "INVALID EMAIL";
                return response;
            }
            try
            {
                var query = "UPDATE_USER_DETAILS";
                var parameters = new DynamicParameters();
                parameters.Add("@UserId", request.UserId, DbType.Int16, ParameterDirection.Input);
                parameters.Add("@Name", request.Name, DbType.String, ParameterDirection.Input);
                parameters.Add("@Email", request.Email, DbType.String, ParameterDirection.Input);
                parameters.Add("@Role", request.Role, DbType.String, ParameterDirection.Input);
                parameters.Add("@Status", request.Status, DbType.String, ParameterDirection.Input);

                using (var connection = _context.CreateConnection())
                {
                    var customerresponse = await connection.ExecuteAsync(query, parameters, commandType: CommandType.StoredProcedure);

                    response.StatusCode = 200;
                    response.Status = "Updated Successfully";
                    return response;
                }
            }
            catch
            {
                response.StatusCode = 500;
                response.Status = "Internal Server Error";
                return response;
            }


        }


        public async Task<int> DeactivateUsers(int UserId)
        {

        
                var query = "DEACTIVATE_USER_LIST";
                var parameters = new DynamicParameters();
                parameters.Add("@UserId", UserId, DbType.Int16, ParameterDirection.Input);
                
                using (var connection = _context.CreateConnection())
                {
                    var customerresponse = await connection.ExecuteAsync(query, parameters, commandType: CommandType.StoredProcedure);
                    return customerresponse;
                }
           
           


        }


        public bool IsValidEmail(string emailaddress)
        {

            var pattern = @"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$"; // checking   "example@example.com"
            var regex = new Regex(pattern);

            if (regex.IsMatch(emailaddress))
            {
                return true;

            }
            else
            {
                return false;
            }

        }
    }
}
